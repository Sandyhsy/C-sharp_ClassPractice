﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("請輸入身高(cm)："); // 提示用戶輸入身高
        float height = float.Parse(Console.ReadLine());// 讀取用戶輸入的身高並將其轉換為浮點數(以便做計算)

        Console.Write("請輸入體重(kg)：");// 提示用戶輸入體重
        float weight = float.Parse(Console.ReadLine());// 讀取用戶輸入的體重並將其轉換為浮點數(以便做計算)

        // 計算BMI（身體質量指數），BMI = 體重（kg） / （身高（m）的平方）
        float bmi = weight / ((height / 100) * (height / 100));

        // 創建一個字符串變數來存儲BMI評估消息
        String message_line;

        // 根據計算得到的BMI值，設定相應的評估消息
        if (bmi < 18.5)
        {
            message_line = "體重過輕";
        }
        else if (bmi > 24)
        {
            message_line = "體重過重";
        }
        else
        {
            message_line = "體重適中";
        }

        Console.Write("您的BMI:" + bmi + "，" + message_line);// 顯示用戶的BMI值和相應的評估消息
    }
}