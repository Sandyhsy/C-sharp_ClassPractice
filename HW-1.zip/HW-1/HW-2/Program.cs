﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("請輸入樹的大小(3以上的整數)：");
        int num = int.Parse(Console.ReadLine());
        // 最後一排的星星數量計算（以便計算樹幹數量）
        int row = num * 2 - 1;

        // 檢查輸入是否小於3
        if (num < 3)
        {
            Console.Write("請輸入3以上的整數！");
        }
        else
        {
            // 繪製樹冠（上半部分）
            for (int tree = 0; tree < 2; tree++)
            {
                // 繪製每一行
                for (int i = 0; i < num; i++)
                {
                    // 繪製左側的空格
                    for (int j = num - i - 1; j > 0; j--)
                    {
                        Console.Write(" ");
                    }

                    // 繪製左側的星號
                    for (int k = 0; k <= i; k++)
                    {
                        Console.Write("*");
                    }

                    // 繪製右側的星號
                    for (int l = 0; l < i; l++)
                    {
                        Console.Write("*");
                    }

                    Console.WriteLine(); // 換行
                }
            }

            // 繪製樹幹
            for (int trunk = 0; trunk < 2; trunk++)
            {
                // 繪製樹幹的空格
                for (int blank = 0; blank < 2; blank++)
                {
                    Console.Write(" ");
                }

                // 繪製樹幹的星號
                for (int star = 0; star < (row - 4); star++)
                {
                    Console.Write("*");
                }

                Console.WriteLine(); // 換行
            }
        }
    }
}
