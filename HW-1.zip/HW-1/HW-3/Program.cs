﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("請輸入身分證字號：");
        string idNumber = Console.ReadLine().ToUpper(); // 將輸入轉換為大寫字母

        if (IsValidIdNumber(idNumber)) // 輸出是否為合法的身分證字號
        {
            Console.WriteLine("這是一個合法的身分證字號。");
        }
        else
        {
            Console.WriteLine("這不是一個合法的身分證字號。");
        }
    }

    static bool IsValidIdNumber(string idNumber)
    {
        char firstChar = idNumber[0];
    
        // 檢查輸入是否符合長度要求
        if (idNumber.Length != 10)
        {
            return false;
        }
        // 檢查第一個字母是否為合法的英文字母
        else if (firstChar < 'A' || firstChar > 'Z')
        {
            return false;
        }
        else
        {
            // 字母對應的數字
            int[] letterMapping = { 10, 11, 12, 13, 14, 15, 16, 17, 34, 18, 19, 20, 21, 22, 35, 23, 24, 25, 26, 27, 28, 29, 32, 30, 31, 33 };
            // 倍率
            int[] multipliers = { 1, 9, 8, 7, 6, 5, 4, 3, 2, 1, 1 };
            // 第一個字母對應的數字
            int lettersum = letterMapping[firstChar - 'A'];
            int numtotal = 0;

            // 計算身分證乘上倍率
            int lettertotal = (lettersum / 10 * multipliers[0]) + (lettersum % 10 * multipliers[1]);

            for (int i = 1; i < 10; i++)
            {
                char currentChar = idNumber[i];
                int digit = currentChar - '0'; // 將字符轉換為數字

                if (currentChar < '0' || currentChar > '9')
                {
                    return false; // 非數字字符
                }
                numtotal += digit * multipliers[i + 1]; // 乘以對應的倍率
            }
            // 檢查身分證是否是10的倍數
            return (lettertotal + numtotal) % 10 == 0;
        }
    }
}
