﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1093325_黃紹瑜
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
