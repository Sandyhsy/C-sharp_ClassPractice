﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace A1093325_1A2B_People
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-----------------------");
            Console.WriteLine("※Game Introduction※");
            Console.WriteLine("Input 4 non-repeating number");
            Console.WriteLine("※Enter Q to end the game");
            Console.WriteLine("Input AAAA to display the answer");
            Console.WriteLine("-----------------------");
            
            String input;
            int count = 0;           

            Random random = new Random();
            List<int> answer = new List<int>();

            /// 亂數產生一組四位不重複的數字
            while (answer.Count < 4)
            {
                int randomNumber = random.Next(1, 10);  /// 設定亂數的範圍在 1~9
                if (!answer.Contains(randomNumber))  /// 若 answer 中不包含亂數選中的數字
                {
                    answer.Add(randomNumber);   /// 就將此亂數加進 answer 陣列中
                }
            }

            /// 實作猜數字的迴圈
            do
            {
                Console.WriteLine("Please input your answer.");
                input = Console.ReadLine();    /// 讀取使用者輸入之數字

                if (CorrectInput(input))    /// 若滿足輸入之規則
                {
                    int[] guess = new int[4];    /// 建立 guess 陣列
                    for (int i = 0; i < 4; i++)
                    {
                        guess[i] = int.Parse(input[i].ToString());    /// 將輸入的數字放進 guess 陣列中
                    }
                    int[] result = CheckGuess(guess, answer.ToArray());
                    Console.WriteLine($"{result[0]}A{result[1]}B");
                    count++;
                    if( CorrectGuess(guess, answer.ToArray()))    /// 使用者輸入之數字與答案相符合就會結束遊戲
                    {
                        Console.WriteLine("Congratulations! You spend" + count + "times");
                        break;
                    }
                }
                else if (input == "AAAA")    /// 使用者輸入 AAAA 便會顯示答案
                {
                    Console.WriteLine("Answer: " + string.Join("", answer));
                }
                else if (input == "Q")    /// 使用者輸入 Q 即結束遊戲
                {
                    break;
                }
                else    /// 若使用者所輸入之答案不符合規則，則會顯示"輸入答案格式錯誤"字樣
                {
                    Console.WriteLine("Input format error.");
                }
            } while (input != "Q");
        }

        /// <summary>
        ///     查看使用者輸入的資料是否符合規則
        /// </summary>
        /// <param name="guess">使用者所輸入的字串</param>
        /// <returns>若為數字且不重複，則回傳 true；否則回傳 false</returns>
        static bool CorrectInput(String guess)
        {
            var usedNumbers = new bool[10];
            /// 當使用者輸入之長度小於 4 個字時，回傳false
            if(guess.Length != 4)
            {
                return false;
            }
            /// 檢查使用者輸入的每個字是否為 1~9 之數字，且數字不重複
            foreach (char c in guess)
            {
                if (c<'0' || c>'9' || usedNumbers[c - '0'])     /// 使用者輸入的字中有沒有非數字或重複的數字，有則回傳 false
                {
                    return false;
                }
                usedNumbers[c - '0'] = true;
            }
            return true;
        }

        /// <summary>
        ///     檢查使用者的猜測是否正確，並返回 A 和 B
        /// </summary>
        /// <param name="guess">要檢查的猜測</param>
        /// <param name="answer">正確答案的數字列表</param>
        /// <returns>如果猜測與正確答案位置相同，則會回傳幾 A ；若數字相同，則會回傳幾 B。</returns>
        static int[] CheckGuess(int[] guess, int[] answer)
        {
            int[] result = new int[2];
            var count = new int[10];
            /// 檢查數字的位置是否與答案一樣
            for (int i = 0; i < 4; i++)
            {
                if (guess[i] == answer[i])
                {
                    result[0]++;
                }
                else
                {
                    count[answer[i]]++;
                }
            }
            /// 檢查數字是否與答案一樣
            for (int i = 0; i < 4; i++)
            {
                if(guess[i] != answer[i] && count[guess[i]] > 0)
                {
                    result[1]++;
                    count[guess[i]]--;
                }
            }
            return result;
        }

        /// <summary>
        ///     檢查猜測是否與正確答案完全匹配。
        /// </summary>
        /// <param name="guess">要檢查的猜測</param>
        /// <param name="answer">正確答案的數字列表</param>
        /// <returns>如果猜測與正確答案完全匹配，則為 true；否則為 false。</returns>
        static bool CorrectGuess(int[] guess, int[] answer)
        {
            // 使用 SequenceEqual 比較 guess 和 answer 是否相等。
            // 若相同，則返回 true；否則返回 false。
            return guess.SequenceEqual(answer);
        }



    }
}