﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace A1093325_Hangman
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> wordLibrary = PrepareWordLibrary();  // 透過 wordLibrary 來完成 Hangman 的遊戲邏輯
            Random random = new Random();   // 隨機物件設置
            int i = random.Next(0, wordLibrary.Count);    // 定義隨機選取的範圍
            string answer = wordLibrary[i];
            List<char> guessedLetters = new List<char>();  // 建立 guessedWord 儲存已猜過且正確的字母
            char input;   // 讀取使用者輸入的字
            int mistakes = 0;  // 計算猜錯次數

            Console.Write("Hangman Begin. Here is the hint.");
            for (int j = 0; j < answer.Length; j++) // 將字數輸出
            {
                Console.Write("[]");
            }
            Console.WriteLine("The length of the word is" + answer.Length);

            do
            {
                Console.WriteLine("Enter your guessed word, any letter between a ~ z , ex: a");
                input = Console.ReadKey().KeyChar; // 讀取使用者所輸入之字

                if (char.IsLetter(input))
                {
                    if (guessedLetters.Contains(input))     // 當使用者重複猜同樣的字母時，會增加錯誤次數，並輸出"你猜錯了"字樣
                    {
                        mistakes++;
                        DrawHangman(mistakes);
                        Console.WriteLine("Wrong");
                    }
                    else if (answer.Contains(input))    // 當使用者輸入之字母與隨機單字匹配時，將
                    {
                        guessedLetters.Add(input);
                        Console.WriteLine("");
                        Console.WriteLine($"You are right!{DisplayGuessedWord(answer, guessedLetters)}");
                    }
                    else
                    {
                        guessedLetters.Add(input);
                        mistakes++;
                        DrawHangman(mistakes);
                        Console.WriteLine("Wrong");
                    }

                    if (answer == DisplayGuessedWord(answer, guessedLetters))   // 當使用者猜對單字時輸出"你贏了"字樣，並結束遊戲
                    {
                        Console.WriteLine("You win!");
                        break;
                    }
                }

                if (mistakes == 5)  // 使用者猜錯5次時會出現"你輸了"字樣
                {
                    Console.WriteLine($"You lost! The correct answer is: {answer}");
                    Console.WriteLine("Press Enter ot exit.");
                    var key = Console.ReadKey();
                    if (key.Key == ConsoleKey.Enter)
                    {
                        break;
                    }
                }
                else  // 當使用者輸入非字母時的提示字樣
                {
                    Console.WriteLine("\nInput error, please try again.");
                }
            } while (answer != DisplayGuessedWord(answer, guessedLetters));
        }

        /// <summary>
        ///     依據輸入錯誤之次數畫出 hangman 造型之 function
        /// </summary>
        /// <param name="mistakes">使用者猜錯之次數</param>
        private static void DrawHangman(int mistakes)
        {
            List<string> drawBase = new List<string>();
            drawBase.Add(@"--------");
            drawBase.Add(@"       |");
            drawBase.Add(@"       O");
            drawBase.Add(@"      /|\ ");
            drawBase.Add(@"      / \ ");
            Console.WriteLine("\n============");
            for (int i = 0; i < mistakes; i++)
            {
                Console.WriteLine(drawBase[i]);
            }
            Console.WriteLine("============");
        }

        /// <summary>
        ///     顯示猜對之字母擺放的位置
        /// </summary>
        /// <param name="answer">為隨機單字</param>
        /// <param name="guessedLetters">為猜對之字母</param>
        /// <returns>回傳猜對字母位置的提示</returns>
        private static string DisplayGuessedWord(string answer, List<char> guessedLetters)
        {
            string display = "";
            foreach (char letter in answer)
            {
                if (guessedLetters.Contains(letter))    // 猜對字母的輸出方式
                {
                    display += "[" + letter + "]";
                }
                else
                {
                    display += "[]";
                }
            }
            return display;
        }

        /// <summary>
        ///     從文字檔案中讀取單字清單
        /// </summary>
        /// <returns>回傳 List<string>，包含自文字檔案中讀取的單字</returns>
        private static List<string> PrepareWordLibrary()
        {
            List<string> wordLibrary = new List<string>();  // 建立一個空的 List 來存放單字清單
            var lines = File.ReadAllLines(Path.Combine(System.Environment.CurrentDirectory, "WordLibrary.txt"));    // 讀取文字檔案的所有行
            foreach (var item in lines) // 逐行處理文字檔案的內容
            {
                wordLibrary.Add(item.Split(',')[0]);    // 將每行內容根據逗號分割，並取得分割後的第一部分，即為英文單字
            }
            return wordLibrary;
        }
    }
}
