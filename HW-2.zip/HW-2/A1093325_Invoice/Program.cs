﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1093325_Invoice
{
    class Program
    {
        static void Main(string[] args)
        {
            String input;
            // 特別獎
            String surpriseNo = "20783987";
            // 特獎
            String specialNo = "04135859";
            // 頭獎
            String lotteryNo1 = "94899145";
            String lotteryNo2 = "71143793";
            String lotteryNo3 = "41055355";
            String[] lotteryNo = { lotteryNo1, lotteryNo2, lotteryNo3 };

            do
            {
                Console.WriteLine("Please enter the Invoice number or enter 'Q' to end.");
                input = Console.ReadLine();

                if (CorrectInput(input))
                {
                    String result = LotteryRule.CheckLottery(input, surpriseNo, specialNo, lotteryNo);
                    Console.WriteLine(result);
                }
                else if (input == "Q")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Format error.");
                }

            } while (input != "Q");
        }

        /// <summary>
        /// 檢查使用者輸入之字串是否為符合規則的
        /// </summary>
        /// <param name="input">使用者所輸入的字串</param>
        /// <returns>若全為數字且長度為 8 ，則回傳 true；反之則回傳 false</returns>
        static bool CorrectInput(String input)
        {
            if (input.Length == 8 && input.All(char.IsDigit))
            {
                return true;
            }
            return false;
        }
    }
}
