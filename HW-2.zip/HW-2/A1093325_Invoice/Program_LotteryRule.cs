﻿using System;

public class LotteryRule
{
    public static String CheckLottery(string input, string surpriseNo, string specialNo, string[] lotteryNos)
    {
        if (input == surpriseNo)
        {
            // 中特別獎
            return "Congratulations! You have won the special prize of 10 million NT dollars.";
        }
        else if (input == specialNo)
        {
            // 中特獎
            return "Congratulations! You have won the special prize of 2 million NT dollars.";
        }
        // 檢查頭獎
        foreach (string HeadPrice in lotteryNos)
        {
            if (input.EndsWith(HeadPrice))
            {
                // 中頭獎
                return "Congratulations! You have won the first prize of 200,000 NT dollars.";
            }
            else if(HeadPrice.Substring(7) == input.Substring(7))
            {
                // 中二獎
                return "Congratulations! You have won the second prize of 40,000 NT dollars.";
            }
            else if (HeadPrice.Substring(6) == input.Substring(6))
            {
                // 中三獎
                return "Congratulations! You have won the third prize of 10,000 NT dollars.";
            }
            else if (HeadPrice.Substring(5) == input.Substring(5))
            {
                // 中四獎
                return "Congratulations! You have won the forth prize of 4,000 NT dollars.";
            }
            else if (HeadPrice.Substring(4) == input.Substring(4))
            {
                // 中五獎
                return "Congratulations! You have won the fifth prize of 1,000 NT dollars.";
            }
            else if (HeadPrice.Substring(3) == input.Substring(3))
            {
                // 中六獎
                return "Congratulations! You have won the sixth prize of 200 NT dollars.";
            }
        }
        return "Lose"; // 沒中獎
    }
}
