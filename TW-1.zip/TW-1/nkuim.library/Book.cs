﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NKUIM.Library.Models
{
    /// <summary>
    /// 書籍資料
    /// </summary>
    public class Book
    {
        /// <summary>
        /// 書籍ID，唯一值
        /// </summary>
        public int BookId { get; set; }
        /// <summary>
        /// 書籍名稱
        /// </summary>
        public string BookName { get; set; }
        /// <summary>
        /// 書籍類別ID
        /// </summary>
        public string BookClassId { get; set; }
        /// <summary>
        /// 書籍作者
        /// </summary>

        public string BookAuthor { get; set; }
        /// <summary>
        /// 書籍購書日期
        /// </summary>

        public DateTime BookBoughtDate { get; set; }
        /// <summary>
        /// 書籍出版商
        /// </summary>
        public string BookPublisher { get; set; }
        /// <summary>
        /// 書籍內容
        /// </summary>

        public string BookNote { get; set; }
        /// <summary>
        /// 書籍狀態ID
        /// </summary>
        public string BookStatusId { get; set; }
        /// <summary>
        /// 書籍借閱人ID
        /// </summary>

        public string BookKeeperId { get; set; }
        /// <summary>
        /// 書籍金額
        /// </summary>

        public int BookAmount { get; set; }


    }
}
