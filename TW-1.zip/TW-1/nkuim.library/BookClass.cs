﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NKUIM.Library.Models
{
    /// <summary>
    /// 書籍類別
    /// </summary>
    public class BookClass
    {
        /// <summary>
        /// 書籍類別ID，唯一值
        /// </summary>
        public string BookClassId { get; set; }
        /// <summary>
        /// 書籍類別名稱
        /// </summary>
        public string BookClassName { get; set; }
    }
}
