﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using NKUIM.Library.Models;

namespace NKUIM.Library
{
    public partial class BookForm : Form
    {
        private List<BookClass> _bookClassData = new List<BookClass>();

        public List<BookClass> BookClassData 
        {
            get { return _bookClassData; }
            set { _bookClassData = value; } 
        }

        private List<BookStatus> _bookStatusData = new List<BookStatus>();
        public List<BookStatus> BookStatusData 
        {
            get { return _bookStatusData; }
            set { _bookStatusData = value; }
        }

        private List<Member> _memberData = new List<Member>();
        public List<Member> MemberData 
        {
            get { return _memberData; }
            set { _memberData = value; } 
        }

        private Book _book = new Book();
        public Book Book
        {
            set 
            {
                _book = value; 
            }
            get
            {
                return _book;
            }
        }

        private string _operator;
        public string Operator
        {
            get
            {
                return _operator;
            }
        }

        public BookForm()
        {
            InitializeComponent();
        }
        private void BookForm_Load(object sender, EventArgs e)
        {

            InitialControl();
            
            //修改狀態
            if (_book.BookId!=0) {

                this.txtBookName.Text = _book.BookName;
                this.txtBookAuthor.Text = _book.BookAuthor;
                this.txtBookNote.Text = _book.BookNote;
                this.txtBookPublisher.Text = _book.BookPublisher;
                this.txtBookAmount.Text = _book.BookAmount.ToString();
                this.cboBookClass.SelectedValue = _book.BookClassId;
                this.cboBookKeeper.SelectedValue = _book.BookKeeperId;
                this.cboBookStatus.SelectedValue = _book.BookStatusId;
                this.dteBookBoughtDate.Value = _book.BookBoughtDate;
                SetBorrowerComboBoxReadOnly();
            }


            //新增狀態
            if (_book.BookId == 0)
            {
                //TODO:隱藏借閱人與借閱狀態
                this.label6.Visible = false;
                this.cboBookKeeper.Visible = false;
                this.label7.Visible = false;
                this.cboBookStatus.Visible = false;
            }
        }

        // 根據借閱狀態設定借閱人 ComboBox 的唯讀狀態
        private void SetBorrowerComboBoxReadOnly()
        {
            string selectedStatus = this.cboBookStatus.SelectedValue.ToString();

            // 如果借閱狀態為不可借出或可以借出，將借閱人 ComboBox 設定為唯讀
            if (selectedStatus == "C" || selectedStatus == "A")
            {
                this.cboBookKeeper.Enabled = false;
            }

        }

        private void DteBookBoughtDate_ValueChanged(object sender, EventArgs e)
        {
            this.dteBookBoughtDate.CustomFormat = "yyyy/MM/dd";
        }

        private void DteBookBoughtDate_KeyDown(object sender, KeyEventArgs e)
        {
            //TODO:如果按下 Delete 或 Backspace，才會進入判斷式中 If you press Delete or Backspace, you will enter the judgment.
            if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
            {
                this.dteBookBoughtDate.CustomFormat = " ";
            }
        }

        /// <summary>
        /// 存檔
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {

            if (ValidateInput())
            {
                
                _book = new Book
                {
                    BookId = _book.BookId,
                    BookName = this.txtBookName.Text,
                    BookClassId = this.cboBookClass.SelectedValue == null ? "" : this.cboBookClass.SelectedValue.ToString(),
                    BookPublisher = this.txtBookPublisher.Text,
                    BookAuthor = this.txtBookAuthor.Text,
                    BookBoughtDate = this.dteBookBoughtDate.Value,
                    BookNote = this.txtBookNote.Text,
                    BookAmount = int.Parse(this.txtBookAmount.Text)
                };


                //修改狀態
                if (_book.BookId != 0)
                {
                    _book.BookStatusId = 
                        this.cboBookStatus.SelectedValue == null?"":
                            this.cboBookStatus.SelectedValue.ToString();

                    string changeStatus= this.cboBookStatus.SelectedValue.ToString();
                    //if (currentStatus != changeStatus)
                    //{
                    //    this.cboBookKeeper.SelectedValue = "0001";
                    //}

                    if (changeStatus == "C" || changeStatus == "A")
                    {
                        this.cboBookKeeper.SelectedValue = "0006";
                    }
                 

                    _book.BookKeeperId = this.cboBookKeeper.SelectedValue == null?"":
                            this.cboBookKeeper.SelectedValue.ToString() ;

                    _operator = "Modify";
                }
                else//新增狀態
                {
                    //TODO:新增時，借閱狀態預設為 A  When adding, the borrowing status defaults to A
                    _book.BookStatusId = "A";
                    //TODO:新增時，借閱人預設為空 When adding a new borrower, the default borrower is empty.
                    _book.BookKeeperId = "";
                    _operator = "Create";
                }
                this.Close();
            }
        }
           

        /// <summary>
        /// 檢查輸入是否合法
        /// </summary>
        /// <returns></returns>
        private bool ValidateInput()
        {
            List<string> message = new List<string>();
            if (this.txtBookName.Text == string.Empty)
            {
                message.Add("請輸入書名");
            }
            if (this.cboBookClass.SelectedValue == null)
            {
                message.Add("請輸入圖書類別");
            }
            if (this.txtBookAuthor.Text == string.Empty)
            {
                message.Add("請輸入作者");
            }
            if (this.txtBookPublisher.Text == string.Empty)
            {
                message.Add("請輸入出版商");
            }
            if (this.dteBookBoughtDate.Text.Trim() == string.Empty)
            {
                message.Add("請輸入購書日期");
            }
            if (this.txtBookNote.Text == string.Empty)
            {
                message.Add("請輸入內容簡介");
            }
            //TODO:如果畫面上有借閱狀態、借閱人控制項，也需要進行輸入判斷 If there are 借閱狀態 and 借閱人 control items on the screen, input judgment is also required.
            if (cboBookStatus.Visible && cboBookKeeper.Visible)
            {
                string tmp = this.cboBookStatus.SelectedValue== null? "" : this.cboBookStatus.SelectedValue.ToString();

                //TODO:如果有借閱狀態為已借出、已借出(未領)，借閱人不能為空，如果借閱人為空，須顯示 請輸入借閱人
                //If there is a borrowing status of 已借出 or 已借出(未領), the borrower cannot be empty. If the borrower is empty, 請輸入借閱人 must be displayed.
                if (cboBookStatus.Visible && cboBookKeeper.Visible)
                {
                    string selectedStatus = this.cboBookStatus.SelectedValue == null ? "" : this.cboBookStatus.SelectedValue.ToString();

                    // 檢查借閱狀態是否為已借出或已借出(未領)
                    if (selectedStatus == "已借出" || selectedStatus == "已借出(未領)")
                    {
                        // 如果借閱人為空，顯示請輸入借閱人
                        if (string.IsNullOrEmpty(this.cboBookKeeper.Text))
                        {
                            MessageBox.Show("請輸入借閱人", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            //// 將焦點設置回借閱人控制項
                            //this.cboBookKeeper.Focus();
                        }
                    }
                }

            }
            if (this.txtBookAmount.Text.Trim() != "")
            {
                //TODO:購書金額僅能輸入數字，如果輸入錯誤，須顯示 購書金額請輸入數字
                //Only numbers can be entered for the book purchase amount. If an error is entered, 購書金額請輸入數字 must be displayed.
                if (!IsNumeric(this.txtBookAmount.Text.Trim()))
                {
                    message.Add("購書金額請輸入數字");
                }
            }
            else
            {
                this.txtBookAmount.Text = "0";
            }
            //TODO:什麼情況下需要顯示訊息 When should a message be displayed?
            if (message.Count > 0)
            {
                MessageBox.Show(string.Join(Environment.NewLine, message),
                    "圖書系統", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            else
            {
                return true;
            }
        }
        private static bool IsNumeric(string value)
        {
            return double.TryParse(value, out _);
        }
        private void InitialControl()
        {
            this.cboBookClass.DataSource = _bookClassData;
            this.cboBookClass.ValueMember = "BookClassId";
            this.cboBookClass.DisplayMember = "BookClassName";

            this.cboBookKeeper.DataSource = _memberData;
            this.cboBookKeeper.ValueMember = "MemberId";
            this.cboBookKeeper.DisplayMember = "MemberName";

            this.cboBookStatus.DataSource = _bookStatusData;
            this.cboBookStatus.ValueMember = "StatusId";
            this.cboBookStatus.DisplayMember = "StatusName";

            this.dteBookBoughtDate.CustomFormat = " ";
            this.dteBookBoughtDate.Format = DateTimePickerFormat.Custom;

            this.dteBookBoughtDate.KeyDown += DteBookBoughtDate_KeyDown;
            this.dteBookBoughtDate.ValueChanged += DteBookBoughtDate_ValueChanged;
        }
    }
}