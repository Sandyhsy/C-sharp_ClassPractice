﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NKUIM.Library.Models
{
    public class BookSearchArg
    {
        public string BookName { get; set; }
        public string BookClassId { get; set; }
        public string BookKeeperId { get; set; }
        public string BookStatusId { get; set; }
        public string BookBoughtStartDate { get; set; }
        public string BookBoughtEndDate { get; set; }
    }
}
