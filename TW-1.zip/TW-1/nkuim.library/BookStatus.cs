﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NKUIM.Library.Models
{
    /// <summary>
    /// 書籍狀態
    /// </summary>
    public class BookStatus
    {
        /// <summary>
        /// 書籍狀態ID，唯一值
        /// </summary>
        public string StatusId { get; set; }
        /// <summary>
        /// 書籍狀態名稱
        /// </summary>
        public string StatusName { get; set; }
    }
}
