﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NKUIM.Library.Models
{
    public class GridResult
    {
        public int BookId { get; set; }

        public string BookName { get; set; }

        public string BookClass { get; set; }

        public string BookBoughtDate { get; set; }

        public string BookStatus { get; set; }

        public string BookKeeper { get; set; }
    }
}
