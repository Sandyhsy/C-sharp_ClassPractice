﻿
namespace NKUIM.Library
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnQuery = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cboBookClass = new System.Windows.Forms.ComboBox();
            this.dteBookBoughtEndDate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dteBookBoughtStartDate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkBookStatusNotReceived = new System.Windows.Forms.CheckBox();
            this.chkBookStatusNotLendable = new System.Windows.Forms.CheckBox();
            this.chkBookStatusAlready = new System.Windows.Forms.CheckBox();
            this.chkBookStatusAvailable = new System.Windows.Forms.CheckBox();
            this.txtBookName = new System.Windows.Forms.TextBox();
            this.cboBookKeeper = new System.Windows.Forms.ComboBox();
            this.dgResult = new System.Windows.Forms.DataGridView();
            this.BookId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookClass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookBoughtDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookKeeper = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Modify = new System.Windows.Forms.DataGridViewLinkColumn();
            this.Delete = new System.Windows.Forms.DataGridViewLinkColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgResult)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCreate
            // 
            this.btnCreate.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCreate.Location = new System.Drawing.Point(116, 350);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(77, 36);
            this.btnCreate.TabIndex = 13;
            this.btnCreate.Text = "新增";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnQuery
            // 
            this.btnQuery.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnQuery.Location = new System.Drawing.Point(26, 350);
            this.btnQuery.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(77, 36);
            this.btnQuery.TabIndex = 12;
            this.btnQuery.Text = "查詢";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(25, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "書名";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(24, 160);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "購書日期";
            // 
            // cboBookClass
            // 
            this.cboBookClass.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cboBookClass.FormattingEnabled = true;
            this.cboBookClass.Location = new System.Drawing.Point(30, 107);
            this.cboBookClass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboBookClass.Name = "cboBookClass";
            this.cboBookClass.Size = new System.Drawing.Size(149, 28);
            this.cboBookClass.TabIndex = 4;
            this.cboBookClass.SelectedIndexChanged += new System.EventHandler(this.cboBookClass_SelectedIndexChanged);
            // 
            // dteBookBoughtEndDate
            // 
            this.dteBookBoughtEndDate.Checked = false;
            this.dteBookBoughtEndDate.CustomFormat = "yyyy-MM-dd";
            this.dteBookBoughtEndDate.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dteBookBoughtEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dteBookBoughtEndDate.Location = new System.Drawing.Point(207, 183);
            this.dteBookBoughtEndDate.Name = "dteBookBoughtEndDate";
            this.dteBookBoughtEndDate.Size = new System.Drawing.Size(142, 29);
            this.dteBookBoughtEndDate.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(26, 83);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "圖書類別";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(182, 183);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "~";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(26, 231);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "借閱狀態";
            // 
            // dteBookBoughtStartDate
            // 
            this.dteBookBoughtStartDate.Checked = false;
            this.dteBookBoughtStartDate.CustomFormat = "yyyy-MM-dd";
            this.dteBookBoughtStartDate.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dteBookBoughtStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dteBookBoughtStartDate.Location = new System.Drawing.Point(28, 183);
            this.dteBookBoughtStartDate.Name = "dteBookBoughtStartDate";
            this.dteBookBoughtStartDate.Size = new System.Drawing.Size(151, 29);
            this.dteBookBoughtStartDate.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(205, 83);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "借閱人";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chkBookStatusNotReceived);
            this.panel1.Controls.Add(this.chkBookStatusNotLendable);
            this.panel1.Controls.Add(this.chkBookStatusAlready);
            this.panel1.Controls.Add(this.chkBookStatusAvailable);
            this.panel1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel1.Location = new System.Drawing.Point(30, 254);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(273, 74);
            this.panel1.TabIndex = 11;
            // 
            // chkBookStatusNotReceived
            // 
            this.chkBookStatusNotReceived.AutoSize = true;
            this.chkBookStatusNotReceived.Location = new System.Drawing.Point(119, 42);
            this.chkBookStatusNotReceived.Name = "chkBookStatusNotReceived";
            this.chkBookStatusNotReceived.Size = new System.Drawing.Size(118, 24);
            this.chkBookStatusNotReceived.TabIndex = 3;
            this.chkBookStatusNotReceived.Text = "已借出(未領)";
            this.chkBookStatusNotReceived.UseVisualStyleBackColor = true;
            // 
            // chkBookStatusNotLendable
            // 
            this.chkBookStatusNotLendable.AutoSize = true;
            this.chkBookStatusNotLendable.Location = new System.Drawing.Point(8, 42);
            this.chkBookStatusNotLendable.Name = "chkBookStatusNotLendable";
            this.chkBookStatusNotLendable.Size = new System.Drawing.Size(92, 24);
            this.chkBookStatusNotLendable.TabIndex = 2;
            this.chkBookStatusNotLendable.Text = "不可借出";
            this.chkBookStatusNotLendable.UseVisualStyleBackColor = true;
            // 
            // chkBookStatusAlready
            // 
            this.chkBookStatusAlready.AutoSize = true;
            this.chkBookStatusAlready.Location = new System.Drawing.Point(119, 12);
            this.chkBookStatusAlready.Name = "chkBookStatusAlready";
            this.chkBookStatusAlready.Size = new System.Drawing.Size(76, 24);
            this.chkBookStatusAlready.TabIndex = 1;
            this.chkBookStatusAlready.Text = "已借出";
            this.chkBookStatusAlready.UseVisualStyleBackColor = true;
            // 
            // chkBookStatusAvailable
            // 
            this.chkBookStatusAvailable.AutoSize = true;
            this.chkBookStatusAvailable.Location = new System.Drawing.Point(8, 12);
            this.chkBookStatusAvailable.Name = "chkBookStatusAvailable";
            this.chkBookStatusAvailable.Size = new System.Drawing.Size(92, 24);
            this.chkBookStatusAvailable.TabIndex = 0;
            this.chkBookStatusAvailable.Text = "可以借出";
            this.chkBookStatusAvailable.UseVisualStyleBackColor = true;
            // 
            // txtBookName
            // 
            this.txtBookName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBookName.Location = new System.Drawing.Point(28, 39);
            this.txtBookName.Name = "txtBookName";
            this.txtBookName.Size = new System.Drawing.Size(328, 29);
            this.txtBookName.TabIndex = 1;
            this.txtBookName.TextChanged += new System.EventHandler(this.txtBookName_TextChanged);
            // 
            // cboBookKeeper
            // 
            this.cboBookKeeper.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cboBookKeeper.FormattingEnabled = true;
            this.cboBookKeeper.Location = new System.Drawing.Point(207, 106);
            this.cboBookKeeper.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboBookKeeper.Name = "cboBookKeeper";
            this.cboBookKeeper.Size = new System.Drawing.Size(149, 28);
            this.cboBookKeeper.TabIndex = 5;
            this.cboBookKeeper.SelectedIndexChanged += new System.EventHandler(this.cboBookKeeper_SelectedIndexChanged);
            // 
            // dgResult
            // 
            this.dgResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgResult.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BookId,
            this.BookClass,
            this.BookName,
            this.BookBoughtDate,
            this.BookStatus,
            this.BookKeeper,
            this.Modify,
            this.Delete});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgResult.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgResult.Location = new System.Drawing.Point(389, 35);
            this.dgResult.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgResult.Name = "dgResult";
            this.dgResult.RowHeadersWidth = 51;
            this.dgResult.RowTemplate.Height = 27;
            this.dgResult.Size = new System.Drawing.Size(665, 458);
            this.dgResult.TabIndex = 15;
            this.dgResult.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgResult_CellContentClick_1);
            // 
            // BookId
            // 
            this.BookId.DataPropertyName = "BookId";
            this.BookId.HeaderText = "BookId";
            this.BookId.MinimumWidth = 6;
            this.BookId.Name = "BookId";
            this.BookId.Visible = false;
            this.BookId.Width = 125;
            // 
            // BookClass
            // 
            this.BookClass.DataPropertyName = "BookClass";
            this.BookClass.HeaderText = "圖書類別";
            this.BookClass.MinimumWidth = 6;
            this.BookClass.Name = "BookClass";
            this.BookClass.Width = 150;
            // 
            // BookName
            // 
            this.BookName.DataPropertyName = "BookName";
            this.BookName.HeaderText = "書名";
            this.BookName.MinimumWidth = 6;
            this.BookName.Name = "BookName";
            this.BookName.Width = 250;
            // 
            // BookBoughtDate
            // 
            this.BookBoughtDate.DataPropertyName = "BookBoughtDate";
            this.BookBoughtDate.HeaderText = "購書日期";
            this.BookBoughtDate.MinimumWidth = 6;
            this.BookBoughtDate.Name = "BookBoughtDate";
            this.BookBoughtDate.Width = 125;
            // 
            // BookStatus
            // 
            this.BookStatus.DataPropertyName = "BookStatus";
            this.BookStatus.HeaderText = "借閱狀態";
            this.BookStatus.MinimumWidth = 6;
            this.BookStatus.Name = "BookStatus";
            this.BookStatus.Width = 125;
            // 
            // BookKeeper
            // 
            this.BookKeeper.DataPropertyName = "BookKeeper";
            this.BookKeeper.HeaderText = "借閱人";
            this.BookKeeper.MinimumWidth = 6;
            this.BookKeeper.Name = "BookKeeper";
            this.BookKeeper.Width = 125;
            // 
            // Modify
            // 
            this.Modify.ActiveLinkColor = System.Drawing.Color.Blue;
            this.Modify.HeaderText = "";
            this.Modify.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Modify.LinkColor = System.Drawing.Color.Blue;
            this.Modify.MinimumWidth = 6;
            this.Modify.Name = "Modify";
            this.Modify.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Modify.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Modify.Text = "修改";
            this.Modify.UseColumnTextForLinkValue = true;
            this.Modify.Width = 70;
            // 
            // Delete
            // 
            this.Delete.HeaderText = "";
            this.Delete.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Delete.LinkColor = System.Drawing.Color.Red;
            this.Delete.MinimumWidth = 6;
            this.Delete.Name = "Delete";
            this.Delete.Text = "刪除";
            this.Delete.UseColumnTextForLinkValue = true;
            this.Delete.Width = 70;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(392, 13);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "查詢結果";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.DefaultExt = "xlsx";
            this.saveFileDialog.FileName = "Output.xlsx";
            this.saveFileDialog.Filter = "Excel documents (.xlsx)|*.xlsx";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1090, 506);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dgResult);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.btnQuery);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cboBookClass);
            this.Controls.Add(this.dteBookBoughtEndDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dteBookBoughtStartDate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtBookName);
            this.Controls.Add(this.cboBookKeeper);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cboBookClass;
        private System.Windows.Forms.DateTimePicker dteBookBoughtEndDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dteBookBoughtStartDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox chkBookStatusNotReceived;
        private System.Windows.Forms.CheckBox chkBookStatusNotLendable;
        private System.Windows.Forms.CheckBox chkBookStatusAlready;
        private System.Windows.Forms.CheckBox chkBookStatusAvailable;
        private System.Windows.Forms.TextBox txtBookName;
        private System.Windows.Forms.ComboBox cboBookKeeper;
        private System.Windows.Forms.DataGridView dgResult;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookId;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookClass;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookName;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookBoughtDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookKeeper;
        private System.Windows.Forms.DataGridViewLinkColumn Modify;
        private System.Windows.Forms.DataGridViewLinkColumn Delete;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}

