﻿using NKUIM.Library.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace NKUIM.Library
{
    public partial class MainForm : Form
    {
        /// <summary>
        /// 書籍類別資料
        /// </summary>
        private List<BookClass> _bookClassData = new List<BookClass>();

        /// <summary>
        /// 書籍狀態資料
        /// </summary>
        private List<BookStatus> _bookStatusData = new List<BookStatus>();

        /// <summary>
        /// 人員資料
        /// </summary>
        private List<Member> _memberData = new List<Member>();

        /// <summary>
        /// 書籍資料
        /// </summary>
        private List<Book> _bookData = new List<Book>();

        public MainForm()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;

            Point NewLoc = Screen.FromControl(this).WorkingArea.Location;
            //Modifiy the location so any toolbars & taskbar can be easily accessed.
            NewLoc.X += 1;
            NewLoc.Y += 1;
            this.Location = NewLoc;

            Size NewSize = Screen.FromControl(this).WorkingArea.Size;
            //Modifiy the size so any toolbars & taskbar can be easily accessed.
            NewSize.Height -= 1;
            NewSize.Width -= 1;
            this.Size = NewSize;

            this.MinimumSize = this.Size;
            this.MaximumSize = this.MinimumSize;   
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitialData();
            InitialControl();
            //TODO:載入後自動查詢 Automatic query after loading
            BindGrid();
        }

        /// <summary>
        /// 取得查詢條件
        /// </summary>
        /// <returns></returns>
        private BookSearchArg ParseBookSearchArg()
        {
            string bookName = this.txtBookName.Text;
            string bookClassId =
                this.cboBookClass.SelectedValue == null ? "" : this.cboBookClass.SelectedValue.ToString();

            string bookKeeperId =
                this.cboBookKeeper.SelectedValue == null ? "" : this.cboBookKeeper.SelectedValue.ToString();

            string bookBoughtStartDate = this.dteBookBoughtStartDate.Text.Trim();
            string bookBoughtEndDate = this.dteBookBoughtEndDate.Text.Trim();

            //TODO:如果沒有輸入就放日期最小值 If there is no input, put the minimum date value
            bookBoughtStartDate = this.dteBookBoughtStartDate.CustomFormat == " " ? DateTime.MinValue.ToString("yyyy/MM/dd") : this.dteBookBoughtStartDate.Text.Trim();
            //TODO:如果沒有輸入就放日期最大值 If there is no input, put the maximum date value 
            bookBoughtEndDate = this.dteBookBoughtEndDate.CustomFormat == " " ? DateTime.MaxValue.ToString("yyyy/MM/dd") : this.dteBookBoughtEndDate.Text.Trim();

            List<string> tempStatusList = new List<string>
            {
                this.chkBookStatusAvailable.Checked ? "A" : "",
                this.chkBookStatusAlready.Checked ? "B" : "",
                this.chkBookStatusNotLendable.Checked ? "C" : "",
                this.chkBookStatusNotReceived.Checked ? "U" : ""
            };

            //TODO:找出 tempStatusList 中值不為空的資料，並將其轉換成 List   Find the data in tempStatusList that is not empty and convert it into a List
            tempStatusList = tempStatusList.Where(status => !string.IsNullOrEmpty(status)).ToList();
            var bookStatusIds = string.Join(",", tempStatusList);

            return new BookSearchArg()
            {
                BookName = bookName,
                BookClassId = bookClassId,
                BookKeeperId = bookKeeperId,
                BookStatusId = bookStatusIds,
                BookBoughtStartDate = bookBoughtStartDate,
                BookBoughtEndDate = bookBoughtEndDate
            };
        }

        /// <summary>
        /// 將查詢出來的資料綁定到DataGridView中
        /// </summary>
        private void BindGrid()
        {
            //TODO:取得畫面上使用者輸入的查詢條件 Get the query conditions entered by the user on the screen
            var arg = ParseBookSearchArg();
            var result = (from a in _bookData
                            join b in _bookClassData on a.BookClassId equals b.BookClassId
                          //TODO:JOIN條件 JOIN condition
                            join c in _bookStatusData on a.BookStatusId equals c.StatusId
                            join d in _memberData on a.BookKeeperId equals d.MemberId into tmp
                            from de in tmp.DefaultIfEmpty()
                            where
                            //TODO:書名使用模糊查詢 Book Name use fuzzy query
                            (a.BookName.Contains(arg.BookName) || arg.BookName == "") &&
                            (a.BookClassId == arg.BookClassId || arg.BookClassId == "") &&
                            (a.BookKeeperId == arg.BookKeeperId || arg.BookKeeperId == "") &&
                            (
                                a.BookBoughtDate.ToString("yyyy/MM/dd").CompareTo(arg.BookBoughtStartDate) >= 0 &&
                                a.BookBoughtDate.ToString("yyyy/MM/dd").CompareTo(arg.BookBoughtEndDate) <= 0
                            ) &&
                            (arg.BookStatusId.IndexOf(a.BookStatusId) > -1 || arg.BookStatusId == "")
                            select new GridResult
                            {
                                BookId = a.BookId,
                                BookName = a.BookName,
                                //TODO:書籍類別該如何顯示 How to display BookClass
                                BookClass = b.BookClassName,
                                //TODO:日期顯示的格式為何 How to display BookBoughtDate
                                BookBoughtDate = a.BookBoughtDate.ToString("yyyy/MM/dd"),
                                //TODO:書籍狀態該如何顯示 How to display BookStatus
                                BookStatus = c.StatusId + "-" + c.StatusName,
                                BookKeeper =
                                //TODO:借閱人該如何顯示 How to display BookKeeper
                                de != null ? de.MemberName : string.Empty
                            }).ToList();

            this.dgResult.DataSource = result;
        }

        /// <summary>
        /// 新增/編輯的資料面操作
        /// </summary>
        /// <param name="book"></param>
        private void RefreshGridForBookForm(Book book)
        {
            //如果 BookId 為 0 代表是新增
            if (book.BookId == 0)
            {
                //    //TODO:新增書籍的BookId為目前資料中最大的BookId+1 The BookId of the newly added book is the largest BookId + 1 in the current data.
                //    book.BookId = _bookData.Max(b => b.BookId) + 1;
                //    _bookData.Add(book);
                //    //TODO:除了新增書籍外，該如何提醒使用者新增成功 In addition to adding books, how to remind users that the addition is successful?
                //    MessageBox.Show("新增成功", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (_bookData.Count > 0)
                {
                    book.BookId = _bookData.Max(b => b.BookId) + 1;
                }
                else
                {
                    book.BookId = 1;
                }
                // 在新增書籍時進行檢查，如果狀態是已借出或已借出(未領)，且借閱人為空，則預設一個借閱人
                if ((book.BookStatusId == "B" || book.BookStatusId == "U") && string.IsNullOrEmpty(book.BookKeeperId))
                {
                    book.BookKeeperId = GetDefaultBookKeeperId();
                }
                _bookData.Add(book);
                MessageBox.Show("新增成功", "圖書管理系統", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //如果 BookId 非 0 代表是修改
            else
            {
                //TODO:該如何取得目前要修改的書籍資料 How to obtain the book information currently to be modified
                //Hint:書籍是使用 BookId 進行區分的 Books are distinguished using BookId
                var obj = _bookData.FirstOrDefault(b => b.BookId == book.BookId);
                obj.BookName = book.BookName;
                obj.BookAmount = book.BookAmount;
                obj.BookAuthor = book.BookAuthor;
                obj.BookBoughtDate = book.BookBoughtDate;
                obj.BookClassId = book.BookClassId;
                obj.BookKeeperId = book.BookKeeperId;
                obj.BookNote = book.BookNote;
                obj.BookPublisher = book.BookPublisher;
                obj.BookStatusId = book.BookStatusId;

                if ((obj.BookStatusId == "B" || obj.BookStatusId == "U") && string.IsNullOrEmpty(obj.BookKeeperId))
                {
                    obj.BookKeeperId = GetDefaultBookKeeperId();
                }

                //TODO:除了更新書籍外，該如何提醒使用者更新成功 In addition to updating books, how to remind users that the update is successful?
                MessageBox.Show("更新成功", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //TODO:提醒完使用者後，還需要做什麼 After reminding the user, what else needs to be done?
            // 提醒完使用者後，還需要重新綁定資料
            BindGrid();
        }

        // 一個可能的預設借閱人的實現，您可以根據需要進行修改
        private string GetDefaultBookKeeperId()
        {
            // 在這裡返回您想要預設的借閱人 ID
            return _memberData.FirstOrDefault()?.MemberId ?? "";
        }

        #region Initial

        /// <summary>
        /// 資料初始化
        /// </summary>
        private void InitialData()
        {
            _bookStatusData.Clear();
            _bookStatusData.Add(new BookStatus() { StatusId = "A", StatusName = "可以借出" });
            _bookStatusData.Add(new BookStatus() { StatusId = "B", StatusName = "已借出" });
            _bookStatusData.Add(new BookStatus() { StatusId = "C", StatusName = "不可借出" });
            _bookStatusData.Add(new BookStatus() { StatusId = "U", StatusName = "已借出(未領)" });

            _bookClassData.Clear();
            _bookClassData.Add(new BookClass() { BookClassId = "BK", BookClassName = "Banking" });
            _bookClassData.Add(new BookClass() { BookClassId = "DB", BookClassName = "Database" });
            _bookClassData.Add(new BookClass() { BookClassId = "DH", BookClassName = "Dataware House" });
            _bookClassData.Add(new BookClass() { BookClassId = "EIS", BookClassName = "EIS" });
            _bookClassData.Add(new BookClass() { BookClassId = "IN", BookClassName = "Internet" });
            _bookClassData.Add(new BookClass() { BookClassId = "LG", BookClassName = "Languages" });
            _bookClassData.Add(new BookClass() { BookClassId = "LR", BookClassName = "Laws And Rules" });
            _bookClassData.Add(new BookClass() { BookClassId = "MG", BookClassName = "Management" });
            _bookClassData.Add(new BookClass() { BookClassId = "MK", BookClassName = "Marketing" });
            _bookClassData.Add(new BookClass() { BookClassId = "NW", BookClassName = "Networking" });
            _bookClassData.Add(new BookClass() { BookClassId = "OS", BookClassName = "Operating System" });
            _bookClassData.Add(new BookClass() { BookClassId = "SC", BookClassName = "Security" });
            _bookClassData.Add(new BookClass() { BookClassId = "SE", BookClassName = "Software Engineering" });
            _bookClassData.Add(new BookClass() { BookClassId = "SI", BookClassName = "System Integration" });
            _bookClassData.Add(new BookClass() { BookClassId = "EAI", BookClassName = "應用系統整合" });
            _bookClassData.Add(new BookClass() { BookClassId = "OT", BookClassName = "Others" });
            _bookClassData.Add(new BookClass() { BookClassId = "CHA", BookClassName = "大陸相關書籍" });
            _bookClassData.Add(new BookClass() { BookClassId = "TRCD", BookClassName = "內部訓練課程光碟" });
            _bookClassData.Add(new BookClass() { BookClassId = "SECD", BookClassName = "研討會/產品介紹光碟" });
            _bookClassData.Add(new BookClass() { BookClassId = "MENU", BookClassName = "Menu 操作手冊" });
            _bookClassData.Add(new BookClass() { BookClassId = "ATCD", BookClassName = "公司內部各項活動光碟" });
            _bookClassData.Add(new BookClass() { BookClassId = "FM", BookClassName = "家庭保健" });
            _bookClassData.Add(new BookClass() { BookClassId = "TP", BookClassName = "休閒旅遊" });
            _bookClassData.Add(new BookClass() { BookClassId = "CCS", BookClassName = "客戶案例分享" });

            _memberData.Clear();
            _memberData.Add(new Member() { MemberId = "0001", MemberName = "張三" });
            _memberData.Add(new Member() { MemberId = "0002", MemberName = "李四" });
            _memberData.Add(new Member() { MemberId = "0003", MemberName = "王五" });
            _memberData.Add(new Member() { MemberId = "0004", MemberName = "陳六" });
            _memberData.Add(new Member() { MemberId = "0005", MemberName = "劉七" });
            _memberData.Add(new Member() { MemberId = "0006", MemberName = "" });

            _bookData.Add(new Book()
            {
                BookId = 1,
                BookName = "認識著作權",
                BookClassId = "LR",
                BookAuthor = "內政部",
                BookPublisher = "內政部",
                BookBoughtDate = new DateTime(2021, 1, 1),
                BookNote = "詳盡的介紹著作權法的規範",
                BookStatusId = "A",
                BookKeeperId = "",
                BookAmount = 250
            });
            _bookData.Add(new Book()
            {
                BookId = 2,
                BookName = "成本會計",
                BookClassId = "BK",
                BookAuthor = "Charles T. Horngren",
                BookPublisher = "東華書局",
                BookBoughtDate = new DateTime(2021, 1, 1),
                BookNote = "介紹成本會計",
                BookStatusId = "A",
                BookKeeperId = "",
                BookAmount = 350
            });
            _bookData.Add(new Book()
            {
                BookId = 3,
                BookName = "軟體建構之道",
                BookClassId = "LG",
                BookAuthor = "Steve McConell",
                BookPublisher = "學貫行銷",
                BookBoughtDate = new DateTime(2021, 1, 1),
                BookNote = "code complete",
                BookStatusId = "B",
                BookKeeperId = "0002",
                BookAmount = 250
            });

            _bookData.Add(new Book()
            {
                BookId = 4,
                BookName = "T-SQL 大全 實務學習與問題解決",
                BookClassId = "DB",
                BookAuthor = "Joseph Sack",
                BookPublisher = "旗標出版",
                BookBoughtDate = new DateTime(2021, 1, 1),
                BookNote = "對於每天必須接觸T-SQL，但卻常常遇到客戶要求不知該如何解決，或是查詢的結果與自己想的天差地遠的MIS/DBA/程式開發人員，本書提供數量繁多的常見問題與解答，並且以問題（目的）為導向，容易查閱，平時演練，臨場解決與參考價值兼具。",
                BookStatusId = "B",
                BookKeeperId = "0003",
                BookAmount = 770
            });

            _bookData.Add(new Book()
            {
                BookId = 5,
                BookName = "有效的管理者",
                BookClassId = "MG",
                BookAuthor = "Peter Drucker",
                BookPublisher = "中華企業管理發展中心",
                BookBoughtDate = new DateTime(2021, 1, 1),
                BookNote = "由管理學之父、精心撰寫的管理學權威著作",
                BookStatusId = "A",
                BookKeeperId = "",
                BookAmount = 550
            });
        }

        private void InitialControl()
        {
            //圖書狀態下拉選單
            this.cboBookClass.DataSource = _bookClassData;
            this.cboBookClass.ValueMember = "BookClassId";
            this.cboBookClass.DisplayMember = "BookClassName";
            this.cboBookClass.SelectedIndex = -1;

            //借閱人下拉選單
            this.cboBookKeeper.DataSource = _memberData;
            this.cboBookKeeper.ValueMember = "MemberId";
            this.cboBookKeeper.DisplayMember = "MemberName";
            this.cboBookKeeper.SelectedIndex = -1;

            //設定 DateTimePicker
            this.dteBookBoughtStartDate.CustomFormat = " ";
            this.dteBookBoughtStartDate.Format = DateTimePickerFormat.Custom;
            this.dteBookBoughtStartDate.KeyDown += DteBookBoughtStartDate_KeyDown;
            this.dteBookBoughtStartDate.ValueChanged += DteBookBoughtStartDate_ValueChanged;

            this.dteBookBoughtEndDate.CustomFormat = " ";
            this.dteBookBoughtEndDate.Format = DateTimePickerFormat.Custom;
            this.dteBookBoughtEndDate.KeyDown += DteBookBoughtEndDate_KeyDown;
            this.dteBookBoughtEndDate.ValueChanged += DteBookBoughtEndDate_ValueChanged;

            this.dgResult.AutoGenerateColumns = false;
            this.dgResult.CellContentClick += DgResult_CellContentClick;
        }
        #endregion

        #region event

        private void DteBookBoughtEndDate_ValueChanged(object sender, EventArgs e)
        {
            this.dteBookBoughtEndDate.CustomFormat = "yyyy/MM/dd";
        }

        private void DteBookBoughtEndDate_KeyDown(object sender, KeyEventArgs e)
        {
            //TODO:如果按下 Delete 或 Backspace，才會進入判斷式中 If you press Delete or Backspace, you will enter the judgment.
            if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
            {
                this.dteBookBoughtEndDate.CustomFormat = " ";
            }
        }
        private void DteBookBoughtStartDate_ValueChanged(object sender, EventArgs e)
        {
            this.dteBookBoughtStartDate.CustomFormat = "yyyy/MM/dd";
        }
        private void DteBookBoughtStartDate_KeyDown(object sender, KeyEventArgs e)
        {
            //TODO:如果按下 Delete 或 Backspace，才會進入判斷式中 If you press Delete or Backspace, you will enter the judgment.
            if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
            {
                this.dteBookBoughtStartDate.CustomFormat = " ";
            }
        }

        /// <summary>
        /// DataViewGrid Cell 點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DgResult_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //TODO: 如何從DataGridView中取得bookId How to get bookId from DataGridView
            int bookId = Convert.ToInt32(dgResult.Rows[e.RowIndex].Cells["BookId"].Value);

            //修改
            //TODO: 如何判斷點擊的欄位是否是修改 How to determine whether the clicked field is 修改
            if (e.ColumnIndex == dgResult.Columns["Modify"]?.Index && e.RowIndex >= 0)
            {
                BookForm bookForm = new BookForm
                {
                    BookClassData=_bookClassData,
                    BookStatusData=_bookStatusData,
                    MemberData=_memberData,
                    //TODO:如何取得要被修改的那筆資料 How to obtain the data to be modified
                    Book = _bookData.FirstOrDefault(b => b.BookId == bookId)
                };
                bookForm.ShowDialog();
                if (bookForm.Operator == "Modify")
                {
                    RefreshGridForBookForm(bookForm.Book);
                }
            }

            //刪除
            //TODO: 如何判斷點擊的欄位是否是刪除 How to determine whether the clicked field is 刪除
            if (e.ColumnIndex == dgResult.Columns["Delete"]?.Index && e.RowIndex >= 0)
            {
                //TODO:按下刪除後應該要做什麼 What to do after pressing delete
                //先判斷如書籍已被借出則無法進行刪除

                var book = _bookData.FirstOrDefault(m => m.BookId == bookId);

                if (book != null && (book.BookStatusId == "B" || book.BookStatusId == "U"))
                {
                    MessageBox.Show("書籍已借出，無法刪除！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {

                    if (MessageBox.Show("確定是否刪除？", "確認刪除", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        _bookData.Remove(_bookData.Where(m => m.BookId == bookId).FirstOrDefault());
                        BindGrid();
                        MessageBox.Show("刪除成功", "圖書管理系統", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnQuery_Click(object sender, EventArgs e)
        {
            BindGrid();
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCreate_Click(object sender, EventArgs e)
        {
            BookForm bookForm = new BookForm
            {
                BookClassData = _bookClassData,
                BookStatusData = _bookStatusData,
                MemberData = _memberData
            };
            
            bookForm.ShowDialog();
            if (bookForm.Operator == "Create")
            {
                RefreshGridForBookForm(bookForm.Book);
            }
            
        }
        #endregion

        private void txtBookName_TextChanged(object sender, EventArgs e)
        {
            BindGrid();  // 每次文字變更時都重新執行查詢
        }

        private void cboBookClass_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cboBookKeeper_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dgResult_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
