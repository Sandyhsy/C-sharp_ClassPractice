﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NKUIM.Library.Models
{
    /// <summary>
    /// 人員
    /// </summary>
    public class Member
    {
        /// <summary>
        /// 人員ID，唯一值
        /// </summary>
        public string MemberId { get; set; }
        /// <summary>
        /// 人員名稱
        /// </summary>
        public string MemberName { get; set; }

    }
}
